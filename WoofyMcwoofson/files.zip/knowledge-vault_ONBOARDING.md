# Onboarding Checklist

- [ ] Review `README.md` and project context
- [ ] Read `general-instructions.md` for audit/transition protocol
- [ ] Ensure access to all required repos and tools
- [ ] Complete environment setup per `GMAIL_OAUTH_SETUP.md` and related docs
- [ ] Confirm understanding of credential rotation and security policies
- [ ] Announce presence in team communication channel
- [ ] Document all onboarding questions and findings in this file
- [ ] **Escalation:** For critical blockers or policy decisions, communicate directly in `ORCHESTRATOR_COMMUNICATION_LOG.md`

_Keep this checklist up-to-date for every new team member or agent._