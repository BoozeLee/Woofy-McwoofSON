# 🐶 Branding Assets

This folder contains:
- Logos and profile art for WOOFY McWOOFSON
- Custom badge SVGs (e.g., goodest-boy.svg, security-champion.svg)
- Any additional branding/marketing assets

Use these assets in the README and documentation for consistent branding.