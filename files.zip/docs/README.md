# 🗂️ Documentation Overview

Welcome to WOOFY McWOOFSON’s docs! Here’s what you’ll find:

- User Guide: `user-guide.md`
- Admin Guide: `admin-guide.md`
- Compliance: `/compliance/`
- API Reference: `/api/`
- Architecture: `/architecture/`
- Accessibility: `accessibility.md`
- Internationalization: `i18n.md`
- Legal & Privacy: `TERMS.md`, `PRIVACY.md`, `/legal/incidents.md`
- Standards: `standards.md`
- Locales: `/locales/`